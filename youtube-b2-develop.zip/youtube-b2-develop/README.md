### Youtube clone B2


npm i -g create-react-app
create-react-app myapp
cd myapp
npm start

### Results:

![Home Page](youtubecloneb2-home-page.png?raw=true "Home page")

![Video Page](youtubecloneb2-video-page.png?raw=true "Video page")
